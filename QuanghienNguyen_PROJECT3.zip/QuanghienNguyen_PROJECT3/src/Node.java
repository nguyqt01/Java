
public class Node {
	
	public Node link;
	private int data;
	private int counter;
	
	public Node(int data, Node link) {
		
		this.link = link;
		this.data = data;
		this.counter = 0;
	}
	
	
	public Node addNodeAfter(int element) {
		
		link = new Node(element, link);
		return link;
	}
	
	
	public String toString() {
		
		String field1 = "";
		String field2 = "";
		if(counter < 20) {
			if(String.valueOf(data) != null) {
				field1 += String.valueOf(data);
				//counter++;
			}
			if(link != null) {
				field2 += link;
				//counter++;
			}
			counter++;
			System.out.println(counter);
		}
		
		return field1 +" " + field2;
	}
	
	
	public static int listLength(Node head) {
		Node cursor;
		int numNodes = 0;
		
		for(cursor = head; cursor != null; cursor = cursor.link) {
			numNodes++;
		}
		
		return numNodes;
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//---------------------------------------- NODE SETTERS & GETTTERS ------------------------------------------//
	public int getCounter() {
		return counter;
	}
	public void setCounter(int counter) {
		this.counter = counter;
	}
	public Node getLink() {
		return link;
	}
	public void setLink(Node link) {
		this.link = link;
	}
	public int getData() {
		return data;
	}
	public void setData(int data) {
		this.data = data;
	}
	
}//END CLASS

