
public class Sortings {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//---------------------------------------- INSERTION SORT (Array) -------------------------------------------//
	
	/**
	 * This method performs the insertion sort with an array.
	 * 
	 * @param data - the unsorted array
	 */
	public static void insertionSort(int[] data) {
		
		for(int i = 1; i < data.length; i++) {
			
			int key = data[i];
			int j = i - 1;
			
			while(j >= 0 && data[j] > key) {
				
				data[j + 1] = data[j];
				j--;
			}
			
			data[j + 1] = key;
		}
	}
	
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
//---------------------------------------- INSERTION SORT (Node) ------------------------------------------------//
	
	/**
	 * 	This method performs the insertion sort with a linked list.
	 * 
	 * @param head - the head reference of the unsorted list.
	 * @return - the head node of the sorted linked list.
	 */
	public static Node insertionSort(Node head) {
		
		
		Node inOrder, next, tail = null;
		inOrder = head;
		int temp;
		
		if( (head == null) || (head.getLink() == null) ) {
			return head;
		}
		
		while( (inOrder != null) && (tail != head) ) {
			
			for(next = inOrder; next.getLink() != tail; next = next.getLink()) {
				
				if(next.getData() > next.getLink().getData()) {
					
					temp = next.getData();
					next.setData(next.getLink().getData());
					next.getLink().setData(temp);
				}
			}
			tail = next;
		}
		return head;
	}
	
	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
//---------------------------------------- MERGE SORT (ARRAY) ------------------------------------------------//
	
	/**
	 * 	This method performs the merge sort with an array.
	 * 
	 * @param data - the array being evaluated.
	 * @param first - the starting index of the array.
	 * @param n - the last element of the array.
	 */
	public static void mergeSort(int[] data, int first, int n) {
		
		int firstHalf;
		int secHalf;
		
		if(n > 1) {
			
			firstHalf = n / 2;
			secHalf = n - firstHalf;
			
			mergeSort(data, first, firstHalf);
			mergeSort(data, first + firstHalf, secHalf);
			
			merge(data, first, firstHalf, secHalf);
		}
	}
	
	//------------------------------------ PRIVATE HELPER FOR MERGE SORT (ARRAY)  ----------------------------------------
	/**
	 * 	This is a private helper for the merge sort, it merges two halves of the array.
	 * 
	 * @param data - the array being evaluated.
	 * @param first - the first index of the array.
	 * @param firstHalf - the first half of the array.
	 * @param secHalf - the second half of the array.
	 */
	private static void merge(int[] data, int first, int firstHalf, int secHalf) {
		
		int[] temp = new int[firstHalf + secHalf];
		int copied = 0;
		int copyFirstHalf = 0;
		int copySecHalf = 0;

		while ( (copyFirstHalf < firstHalf) && (copySecHalf < secHalf) ) {
			
			if(data[first + copyFirstHalf] < data[first + firstHalf + copySecHalf]) {
				
				temp[copied] = data[first + copyFirstHalf];
				copied++;
				copyFirstHalf++;
			}
			else {
				
				temp[copied] = data[first + firstHalf + copySecHalf];
				copied++;
				copySecHalf++;
			}
		}
		
		while(copyFirstHalf < firstHalf) {
			
			temp[copied] = data[first + copyFirstHalf];
			copied++;
			copyFirstHalf++;
		}
		
		for(int i = 0; i < copied; i++) {
			data[first + i] = temp[i];
		}
	}

	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//---------------------------------------- MERGE SORT (NODE) ------------------------------------------------//
	
	/**
	 * 	This method uses the getMiddle and sortedMerge to perform the merge sort algorithm.
	 * 
	 * @param head - the starting node of the linked list.
	 * @return - a sorted linked list.
	 */
	public static Node mergeSort(Node head) {
		
		if( (head == null) || (head.getLink() == null) ) {
			return head;
		}
		
		Node middle = getMiddle(head);
		Node nextToMiddle = middle.getLink();
		Node left;
		Node right;
		Node sorted;
		
		middle.setLink(null);
		
		left = mergeSort(head);
		right = mergeSort(nextToMiddle);
		
		sorted = sortedMerge(left, right);
		
		return sorted;
	}
	
	//------------------------------------ PRIVATE HELPER FOR MERGE SORT (NODE)  ----------------------------------------
	/**
	 * 	This method returns the middle node of the linked list, starting from head.
	 * 
	 * @param head - The starting head of the linked list.
	 * @return - the middle node of the linked list.
	 */
	private static Node getMiddle(Node head) {

		Node middle = head;
		Node fast = head.getLink();

		while(fast != null) {
			
			fast = fast.getLink();
			
			if(fast != null) {
				
				middle = middle.getLink();
				fast = fast.getLink();
			}
		}
		return middle;
	}
	
	//------------------------------------ PRIVATE HELPER FOR MERGE SORT (NODE)  ----------------------------------------
	/**
	 * 	This method merges the left and right parts of the linked list.
	 * 
	 * @param left - The head reference to left side of the linked list.
	 * @param right - The head reference to right side of the linked list. 
	 * @return - This method returns a merged linked list, containing the left and right side.
	 */
	private static Node sortedMerge(Node left, Node right) {
		
		Node sortedList = null;
		
		if(left == null) {
			return right;
		}
		if(right == null) {
			return left;
		}
		
		if(left.getData() <= right.getData()) {
			
			sortedList = left;
			sortedList.setLink(sortedMerge(left.link, right));
		}
		else {
			
			sortedList = right;
			sortedList.setLink(sortedMerge(left, right.getLink()));
		}
		
		return sortedList;
	}
	

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//---------------------------------------- HEAP SORT (ARRAY) ------------------------------------------------//
	
	/**
	 * 	This method uses the reheapifyDown and makeHeap to perform the heap sort algorithm
	 * 	 with an array.
	 * 
	 * @param data - the array being evaluated.
	 * @param n - the last index of the array to be evaluated.
	 */
	public static void heapSort(int[] data, int n) {
		
		makeHeap(data, n);
		
		for(int i = n; i >= 0; i--) {
			
			swap(data, 0, i);
			n--;
			reheapifyDown(data, 0, n);
		}
	}
	
	//------------------------------------ PRIVATE HELPER FOR HEAP SORT (ARRAY)  ---------------------------------
	/**
	 * 	This method starts at a parent and uses reheapifyDown to create the initial heap.
	 * 
	 * @param data - The array that is being heapified.
	 * @param n - This is the starting index that is being evaluated/
	 */
	private static void makeHeap(int[] data, int n) {
		
		for(int i = (n - 1) / 2; i >= 0; i--) {
			reheapifyDown(data, i, n - 1);
		}
	}
	
	//------------------------------------ PRIVATE HELPER FOR HEAP SORT (ARRAY)  ---------------------------------
	/**
	 * 	This method uses the reheapifyDown algorithm to sort the heap.
	 * 
	 * @param data - The array that is being evaluated.
	 * @param i - The moving index, from last index of array to root.
	 * @param n - This is the starting index to reheapify down.
	 */
	private static void reheapifyDown(int[] data, int i, int n) {
		
		int left = (2 * i) + 1;
		int right = (2 * i) + 2;
		int higherIndex;
		
		if(left <= n && data[left] > data[i]) {
			higherIndex = left;
		}
		else {
			higherIndex = i;
		}
		
		if(right <= n && data[right] > data[higherIndex]) {
			higherIndex = right;
		}
		
		if(higherIndex != i) {
			
			swap(data, i, higherIndex);
			reheapifyDown(data, higherIndex, n);
		}
	}
	
	//------------------------------------ PRIVATE HELPER FOR HEAP SORT (ARRAY)  ---------------------------------
	/**
	 * 	This is the swap helper method to swap two array indices.
	 * 
	 * @param data - The array being evaluated.
	 * @param i - index being swapped.
	 * @param j - index being swapped.
	 */
	private static void swap(int[] data, int i, int j) {
		
		int temp;
		temp = data[i];
		data[i] = data[j];
		data[j] = temp;
	}	
	
	
}//END SORTINGS CLASS
