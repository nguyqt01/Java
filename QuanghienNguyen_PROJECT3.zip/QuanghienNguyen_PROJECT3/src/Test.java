import java.util.Random;
/*
 *  At Linked List size 60000, Merge sort gives stack overflow.
 *  After the data size of > 160000, insertion sort takes a longer
 *  time to display results. At data size 640000, insertion sort for array
 *  takes 170 seconds to perform.
 *  
 *  - Comment out insertion sort (array) at data set > 1,280,000.
 *  - Comment out insertion sort at node size > 640,000.
 *  - Comment out merge sort at node size > 60,000.
 */
public class Test {
	
	private static int[] data;
	private static Node head;
	private final static int TOP = 12000000;
	private static Random rand = new Random();
	
	public static void main(String[] args) {
 
	/******************************************** TESTING: PHASE 1 *********************************************************/
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////EMPTY STRUCTURE
		System.out.println("Empty Structure results: ");
		System.out.println("----------------------------------------------------------------------------------------------");
		
		data =  new int[0];
		Sortings.insertionSort(data);
		
		displayArray(data.length);
		
		Sortings.mergeSort(data, 0, data.length - 1);
		displayArray(data.length);
		
		Sortings.heapSort(data, data.length - 1);
		displayArray(data.length);
		
		Sortings.insertionSort(head);
		displayList(head);
		
		Sortings.mergeSort(head);
		displayList(head);
		
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////SINGLE ELEMENT STRUCTURE
		System.out.println();
		System.out.println("Single Element Structure results: ");
		System.out.println("----------------------------------------------------------------------------------------------");
				
		data =  new int[]{1};
		head = new Node(1, null);
		
		Sortings.insertionSort(data);
		displayArray(data.length);
		
		Sortings.mergeSort(data, 0, data.length - 1);
		displayArray(data.length);
		
		Sortings.heapSort(data, data.length - 1);
		displayArray(data.length);
		
		Sortings.insertionSort(head);
		displayList(head);
		
		Sortings.mergeSort(head);
		displayList(head);
		
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////TWO ELEMENT STRUCTURE
		System.out.println();
		System.out.println("Two Element Structure results: ");
		System.out.println("----------------------------------------------------------------------------------------------");
					
		data =  new int[]{2,1};
		head = new Node(2, (new Node(1, null)));
		
		Sortings.insertionSort(data);
		displayArray(data.length);
		
		Sortings.mergeSort(data, 0, data.length - 1);
		displayArray(data.length);
		
		Sortings.heapSort(data, data.length - 1);
		displayArray(data.length);
		
		Sortings.insertionSort(head);
		displayList(head);
		
		Sortings.mergeSort(head);
		displayList(head);		
		
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////WROST CASE for INSERTATION (DECREASING ORDER)
		
		System.out.println();
		System.out.println("WORST INSERTION SORT results: ");
		System.out.println("----------------------------------------------------------------------------------------------");
		
		int size = 20000;
		data = new int[size];
		head = new Node((size - 1), null);
		Node currentW = head;
		
		for(int i = (size - 1); i >= 0; i--) {
			data[i] = i;
			if(i < (size - 1)) {
				currentW = currentW.addNodeAfter(i);
			}
		}
		
		testSort();
		
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////BEST CASE for INSERTATION (INCREASING ORDER)
		System.out.println();
		System.out.println("BEST INSERTION SORT results: ");
		System.out.println("----------------------------------------------------------------------------------------------");
		
		data = new int[size];
		head = new Node(0, null);
		Node currentB = head;
		
		for(int i = 0; i < size; i++) {
			data[i] = i;
			if(i > 0) {
				currentB = currentB.addNodeAfter(i);
			}
		}
		
		testSort();
		
		
	/******************************************** TESTING: PHASE 2 ****************************************************************************************/
		//int arrLen = 20;
		//int arrLen = 201; //Boudary Case for displayList and displayArray
		//int arrLen = 5000;
		//int arrLen = 10000;
		int arrLen = 20000;
		//int arrLen = 40000;
		//int arrLen = 50000;
		//int arrLen = 60000;
		//int arrLen = 80000;
		//int arrLen = 160000;
		//int arrLen = 320000;
		//int arrLen = 640000;
		//int arrLen = 1280000;
		//int arrLen = 2560000;
		//int arrLen = 5120000;
		//int arrLen = 10240000;
		
		System.out.println();
		System.out.println("Phase 2 results: ");
		System.out.println("----------------------------------------------------------------------------------------------");
		
		randomData(arrLen);
		testSort();
	}
	
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//------------------------------------------------------- TEST CLASS METHODS ----------------------------------------------------------//
	
	/**
	 * This method Fills the array with integers randomly selected from the range 0 <= x < TOP. Using the same for loop, the method generates the nodes of the list with the same random numbers as used for the array entries.
	 * @param dataLength - the size of list or array being filled
	 */
	private static void randomData(int dataLength) {
		
		data = new int[dataLength];
		head = new Node(rand.nextInt(TOP-1), null);
		
		int randNum;
		Node current = head;
		
		for(int i = 0; i < dataLength; i++) {
			
			randNum = rand.nextInt(TOP-1);
			data[i] = randNum;
			
			if(i > 0) {
				current = current.addNodeAfter(randNum);
			}
		}
	}
	
	
	/**
	 * This method this method calls the sorting methods and measures the running time for each, independent of each other. 
	 * Calls display method(s) to print the time results and to demonstrate the sorting execution.
	 */
	private static void testSort() {
		
		long insertionSortArrayStartTime;
		long insertionSortArrayEndTime;
		double insertionSortArrayDuration;
		
		long insertionSortNodeStartTime;
		long insertionSortNodeEndTime;
		double insertionSortNodeDuration;
		
		long mergeSortArrayStartTime;
		long mergeSortArrayEndTime;
		double mergeSortArrayDuration;
		
		long mergeSortNodeStartTime;
		long mergeSortNodeEndTime;
		double mergeSortNodeDuration;
		
		long heapSortStartTime;
		long heapSortEndTime;
		double heapSortDuration;
		
		insertionSortArrayStartTime = System.nanoTime();
		Sortings.insertionSort(data);
		insertionSortArrayEndTime = System.nanoTime();
		insertionSortArrayDuration = (double) (insertionSortArrayEndTime - insertionSortArrayStartTime) / 1000000000;
		System.out.println("Time taken in seconds for insertion sort (array): " + insertionSortArrayDuration);
		
		mergeSortArrayStartTime = System.nanoTime();
		Sortings.mergeSort(data, 0, data.length - 1);
		mergeSortArrayEndTime = System.nanoTime();
		mergeSortArrayDuration = (double) (mergeSortArrayEndTime - mergeSortArrayStartTime) / 1000000000;
		System.out.println("Time taken in seconds for merge sort (array): " + mergeSortArrayDuration);
		
		heapSortStartTime = System.nanoTime();
		Sortings.heapSort(data, data.length - 1);
		heapSortEndTime = System.nanoTime();
		heapSortDuration = (double) (heapSortEndTime - heapSortStartTime) / 1000000000;
		System.out.println("Time taken in seconds for heap sort: " + heapSortDuration);
		
		insertionSortNodeStartTime = System.nanoTime();
		Sortings.insertionSort(head);
		insertionSortNodeEndTime = System.nanoTime();
		insertionSortNodeDuration = (double) (insertionSortNodeEndTime - insertionSortNodeStartTime) / 1000000000;
		System.out.println("Time taken in seconds for insertion sort (node): " + insertionSortNodeDuration);
		
		// At Linked List size 60000, Merge sort gives stack overflow.
		mergeSortNodeStartTime = System.nanoTime();
		Sortings.mergeSort(head);
		mergeSortNodeEndTime = System.nanoTime();
		mergeSortNodeDuration = (double) (mergeSortNodeEndTime - mergeSortNodeStartTime) / 1000000000;
		System.out.println("Time taken in seconds for merge sort (node): " + mergeSortNodeDuration);
		
		displayArray(data.length); 	//Comment out for easier Testing
		displayList(head);			//Comment out for easier Testing
	}
	
	
	/**
	 * This method print arrays to the console.
	 * @Postcondition: For arrays larger than 200, print only 50 array entries evenly distributed over the total array. 
	 */
	private static void displayArray(int arrLen) {
		
		int counter = 0;
		int i = 0;
		int increment = arrLen / 50;
		
		System.out.println();
		System.out.println("Sorted Array results: ");
		
		if(arrLen > 200) {
			
			while(counter < 50 && i < arrLen) {
				
				System.out.println("Array Element at index: [" + i + "]" + " = " + data[i]);
				counter++;
				i = i + increment;
			}
			System.out.println("Number of items: " + counter);
		}
		else {
			for(i = 0; i < arrLen; i++) {
				System.out.println("Array Element at index: [" + i + "]" + " = " + data[i]);
			}
		}
	}
	
	
	/**
	 * This method print the linked lists to the console.
	 * @Postcondition: For lists larger than 200, print only 50 list entries evenly distributed over the total array. 
	 */
	private static void displayList(Node head) {
		
		System.out.println();
		System.out.println("Node data: ");
		
		int counter = 0;
		int size = Node.listLength(head);
		
		if(size <= 200) {
			Node cursor = head;
			for(int i = 0; i < size; i++) {
				System.out.println(cursor.getData());
				cursor = cursor.getLink();
			}
		}
		else {
			int increment = size / 50;
			Node cursor = head;
			for(int i = 1; i < size; i++) {
				System.out.println(cursor.getData());
				for(int j = 0; j < increment; j++) {
					cursor = cursor.getLink();
				}
				counter++;
				i += increment;
			}
			System.out.println("Number of items: " + counter);
		}
	}
	
}//END CLASS
