/**
 * 
 * 	Quanghien Nguyen
 * 	CS 260 Project 1: Generic ArrayListSeq Set
 * 	Professor Petruska
 * 	Date: 2/17/19
 *	
 */

import java.util.ArrayList; // import the ArrayList class	

public class Sequence<T> implements Cloneable{
	
	private T current;
	private ArrayList<T> list;
	
	/**
	 *  The constructor initializes the generic ArrayList that the sequence is going to be store in be store in
	 *  @Precondition: T
	 *  @Postcondition: This sequence is empty.
	 *  @throws: OutOfMemoryError: Indicates insufficient memory for new ArrayList (no exception thrown req)
	 */
	public Sequence() {
		list = new ArrayList<T>();
	}

	
	
	/**
	 * This method Adds a new element to this sequence after the current element.
	 * @param: element = the new element that is being added 
	 * @precondition: New element cannot be an element that already exist in the list.
	 * @postcondition: 	A new copy of the element has been added to this sequence. If there was a current element,
	 * 					then addAfter places the new element after the current element. If there was no current element, 
	 * 					then addAfter places the new element at the end of this sequence. 
	 * 					In all cases, the new element becomes the new current element of this sequence.
	 * @return - The method returns the element that is add.
	 * @Throws: OutOfMemoryError = Indicates insufficient memory to an element (no exception thrown req)
	 */
	public T addAfter(T element) {
		
		if (current != null) {
			
			int currentIndex = list.indexOf(current);//temp int that store the index of the current Item
			list.add((currentIndex + 1), element);	
			
		}else{
			list.add(element);
		}
		
		current = element;
		return element;
	}
	
	
	
	/**
	 * This method Adds a new element to this sequence before the current element. 
	 * @param: element - the new element that is being added
	 * @precondition: New element cannot be an element that already exist in the list.
	 * @postcondition: 	A new copy of the element has been added to this sequence. If there was a current element,
	 * 					then addBefore places the new element before the current element. If there was no current element, 
	 * 					then addBefore places the new element at the front of this sequence. In all cases, the new element 
	 * 					becomes the new current element of this sequence.
	 * @return - The method returns the element that is add.
	 * @Throws: OutOfMemoryError = Indicates insufficient memory to an element (no exception thrown req)
	 */
	public T addBefore(T element) {
		
		if (current != null && list.indexOf(current) >= 1) {
			
			int currentIndex = list.indexOf(current);//temp int that store the index of the current Item
			list.add((currentIndex), element);	
			
		}else{
			current = element;
			list.add(0, element);
		}
		
		current = element;
		return element;
	}
	
	
	
	/**
	 * This method place the contents of another sequence at the end of this sequence.
	 * @param: other - a sequence whose contents will be placed at the end of this sequence
	 * @precondition: 	The other sequence cannot contain any element that is already in this sequence
	 * @postcondition: 	The elements from other sequence have been placed at the end of this sequence. The current element
	 * 					of this sequence remains where it was, and the other sequence is also unchanged.
	 * @Throws: OutOfMemoryError = Indicates insufficient memory to add other sequence to the sequence (no exception thrown req)
	 */
	public void addAll(Sequence<?> s1) {
		
		if(s1 == null) {
			return;
		}
		
		for (int i = 0; i < s1.getList().size(); i++) {
			list.add((T) s1.getList().get(i));
		}
		
			return;
	}
	
	
	
	/**
	 * This method Create a new sequence that contains all the elements from one sequence followed by another
	 * @param: 	s1 � the first of two sequences
	 * 			s2 � the second of two sequences
	 * @precondition: 	Neither s1 or s2 cannot contain any element that are the same or be null.
	 * @Returns: a new sequence that has the elements of s1 followed by the elements of s2 (with no current element)
	 * @Throws: NullPointerException - Indicates that one of the arguments is null.
	 * 			OutOfMemoryError - Indicates insufficient memory for the new sequence (Not require to be thrown)
	 */
	public static<T>  Sequence<T> concatenate(Sequence<T> s1, Sequence<T> s2){
		
		if (s1 == null || s2 == null) {
			throw new NullPointerException("One of the sequences is null.");
		}
		
		Sequence<T> result = new Sequence<T>();
		
		result.addAll(s1);
		result.addAll(s2);
		
		return result;
	}
	
	
	
	/**
	 * Accessor method to determine whether this sequence has a specified current element that can be retrieved with the getCurrent method.
	 * @Returns: a new sequence that has the elements of s1 followed by the elements of s2 (with no current element)
	 */
	public boolean isCurrent() {
		
		if (current == null) {
			return false;
		}else {
			return true;
		}
	}
	
	
	
	/**
	 * This method removes current if exists and returns the removed element.
	 * @precondition: 	isCurrent( ) returns true.
	 * @postcondition:	The new current is the element right after the removed current if there
	 * 					is such an element. If the last element was removed there is no new current.
	 * 					if there is no current the method returns null
	 * @Returns:  returns the removed element.
	 */
	public T removeCurrent() {
		
		T removed;
		int currentIndex;
		int lastIndex;
		
		if (isCurrent() == false) {
			removed = null;
			return removed;
		}
		
		currentIndex = list.indexOf(current);
		lastIndex = list.size() - 1;
		removed = current;
		
		list.remove(currentIndex);
		
		if (currentIndex == lastIndex) {
			current = null;
		}else {
			current = list.get(currentIndex);
		}
		
		return removed;
	}
	
	
	
	/**
	 * Move forward so that the current element is now the next element in this sequence.
	 * @precondition: 	isCurrent( ) returns true.
	 * @postcondition:	If the current element was already the end element of this sequence (with nothing after it),
	 * 					then there is no longer any current element. Otherwise, the new element is the element
	 * 					immediately after the original current element.
	 * @throws: IllegalStateException - Indicates that there is no current element, so advance may not be called.
	 */
	public void advance() {
		
		int currentIndex;
		
		if (isCurrent() == false) {
			throw new IllegalStateException("There is no current element, so advance may not be called");
		}
		
		currentIndex = list.indexOf(current);
		
		if (currentIndex == (list.size() - 1)) {
			current = null;
		}else {
			current = list.get(currentIndex + 1);
		}
	}
	
	
	
	/**
	 * This method set the current element at the front of this sequence.
	 * @postcondition:	The front element of this sequence is now the current element (but if this sequence has no
	 * 					elements at all, then there is no current element).
	 */
	public void start() {
		
		if (list.size() > 0) {
			setCurrent(list.get(0));
		}
	}
	
	
	
	/**
	 * This method generate a copy of this sequence.
	 * @Returns: 	The return value is a copy of this sequence. Subsequent changes to the copy will not affect
	 * 				the original, nor vice versa.
	 * @Throws: OutOfMemoryError - Indicates insufficient memory for the clone sequence (Not require to be thrown)
	 */
	public Sequence<T> clone(){
		
		Sequence<T> clone;
		
		try {
			
			clone = (Sequence<T>) super.clone();
			clone.list = new ArrayList<T>();
			clone.list.addAll(this.list);
			
		} catch ( CloneNotSupportedException exc ) {
			throw new RuntimeException("Make sure Class impements cloneable");
        }
		
        return clone;
	}
	
	
	
	/**
	 * This accessor method to determine the number of elements in this sequence.
	 * @Returns: the number of elements in this sequence
	 */
	public int size() {
		
		return list.size();
	}
	
	
	
	/**
	 * This convenience method, prints all the elements of Sequence to the console
	 * @post-condition - prints all the elements of Sequence to the console
	 */
	public void displaySequence() {
		
		for(T e: list) {
			System.out.println(e.toString());
		}
	}
	
	
	
	/**
	 *  Define getters and setters.
	 */
	public T getCurrent() {
		return current;
	}

	public void setCurrent(T current) {
		this.current = current;
	}

	public ArrayList<T> getList() {
		return list;
	}

	public void setList(ArrayList<T> list) {
		this.list = list;
	}
	
	
	
	/**
	 * ADT invariant of this Sequence Class 
	 * 1)	The "list" variable is an ArrayList that store the values in the sequence. It is use to call ArrayLists methods
	 * 		that help manipulate the data, find the number of elements, and etc.
	 * 
	 * 2) 	The element stored in the "current" variable is use to find the "currentIndex" through the use of the ArrayList
	 * 		method indexOf(). The variable "current" should be null until an element is added to the list or manually set.
	 * 		
	 * 3)	"currentIndex" is a method variable use to temporary store the index that "current" is store at in the sequence.
	 * 		If there is a current element, then it lies in list.get(currentIndex); if there is no current element, then 
	 * 		currentIndex equals -1 due to the method list.indexOf(current) returning -1 if the object is not found.
	 * 
	 * 4)	If the "current" element is remove then the new value of "current" is the element now stored in the currentIndex of
	 * 		the removed element. "currentIndex" should remain the same after the "current" element is removed.
	 * 
	 * 5)	When an element is added to the list, the added element become the "current" element. If addBefore() was used then
	 * 		"currentIndex" should remain the same. If addAfter() was used, "currentIndex" should have increase by 1.
	 */
	
	
}
