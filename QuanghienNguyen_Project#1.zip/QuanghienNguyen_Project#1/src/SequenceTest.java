import java.util.ArrayList;

/**
 * 
 * 	Quanghien Nguyen
 * 	CS 260 Project 1: Generic ArrayListSeq Set
 * 	Professor Petruska
 * 	Date: 2/17/19
 *	
 */

public class SequenceTest {

	
	public static void main(String[] args) {
		
		//Declare and instantiate a Sequence object using the concrete type Integer; name your Sequence object as series
			
			Sequence<Integer> series = new Sequence<Integer>();
		
		//Declare and instantiate and Integer ArrayList named list; 
		//Assign list the list field of series (just to make your code a bit more concise)
			
			ArrayList<Integer> list = series.getList();
			
		//print** (Should print -1 or object not found since current is null)
			
			System.out.println("Current Index: " + list.indexOf(series.getCurrent()) + " Size: " + series.size());
		
		//Call addAfter( ) five times to add five different element to series and after each call print**
			
			series.addAfter(1);
			System.out.println("Current Index: " + list.indexOf(series.getCurrent()) + " Size: " + series.size());
			series.addAfter(2);
			System.out.println("Current Index: " + list.indexOf(series.getCurrent()) + " Size: " + series.size());
			series.addAfter(3);
			System.out.println("Current Index: " + list.indexOf(series.getCurrent()) + " Size: " + series.size());
			series.addAfter(4);
			System.out.println("Current Index: " + list.indexOf(series.getCurrent()) + " Size: " + series.size());
			series.addAfter(5);
			System.out.println("Current Index: " + list.indexOf(series.getCurrent()) + " Size: " + series.size());
			System.out.println("");
			
		//Call displaySequence()
			
			series.displaySequence();
			System.out.println("");
			
		//set current to the index 1 element of list and call addAfter adding yet another number to the series; print**
			
			series.setCurrent(list.get(1));
			series.addAfter(6);
			System.out.println("Current Index: " + list.indexOf(series.getCurrent()) + " Size: " + series.size());
			System.out.println("");
			
		//Call addBefore() twice adding two new elements and print** after each addition 
			
			series.addBefore(7);
			System.out.println("Current Index: " + list.indexOf(series.getCurrent()) + " Size: " + series.size());
			series.addBefore(8);
			System.out.println("Current Index: " + list.indexOf(series.getCurrent()) + " Size: " + series.size());
			System.out.println("");
			
		//Call displaySequence()
			
			series.displaySequence();
			System.out.println("");
		
		//Set current to the index 6 element of list; call removeCurrent () and print**
			series.setCurrent(list.get(6));
			series.removeCurrent();
			System.out.println("Current Index: " + list.indexOf(series.getCurrent()) + " Size: " + series.size());
			System.out.println("");
			
		//Call clone( ) and assign the return value to another Sequence variable clone
			Sequence<Integer> clone = series.clone();
			
		//Call displaySequence( ) for clone
			clone.displaySequence();
			System.out.println("");
			
		//Check if clone == series and print to the console
			System.out.println(clone == series);
			System.out.println(clone.equals(series));
			System.out.println("");
			
		//Check if the first element of series == the first element of clone and print to the console
			System.out.println(clone.getList().get(1) == series.getList().get(1));
			System.out.println((clone.getList().get(1)).equals(series.getList().get(1)));
			System.out.println("");
			
		//In order to test start( ), isCurrent( ), advance( ) in one, call displaySequence( ) for series once more, then run the for loop as set up in the book, p 147 and compare the prints
			series.displaySequence();
			
			System.out.println("");
			
			for (series.start( ); series.isCurrent( ); series.advance( )) {
				System.out.println(series.getCurrent( ));
			}
			
		/**
		 * Note that methods ensureCapacity( ), getCapacity, trimToSize() discussed in the book are inadequate for our class
		 * None of these methods are need since the sequence class isn't require to initiate a capacity for an ArrayList, unlike
		 * in an array. 
		 * The ArrayList capacity will always be equals to its size so there is no need for getCapacity() when
		 * the class already has size(). 
		 * TrimToSize() is not needed since the ArrayList will always be the minimum size needed. 
		 * No need for ensureCapacity() due to ArrayList automatically make the space need if an ArrayList is not 
		 * declare with a initial limiting capacity,  until memory runs out that is.
		 */

	}

	
}
