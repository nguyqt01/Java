package project2;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.*;

/**
 * 
 * 	Quanghien Nguyen
 * 	CS 260: Project 2
 * 	Professor Petruska
 * 	Date: 3/17/19
 *
 */

public class MazeBuilder {
	
	
	/**
	 * This Method implement generated a random 2D array of Cells that represents a randomly built maze given the users input
	 * Precondition: 0 =< pInput =< 1 , colInput > 0 (doesn't start with 0 such as 01 02 03) , rowInput > 0 (doesn't start with 0 such as 01 02 03)
	 * Post-Condition: Returns 2D array of Cell[][] representing the maze;
	 */
	public static Cell[][] loadMazeRandom(){
		
		double p;
		int cols;
		int rows;
		String pInput;
		String colInput;
		String rowInput;
		Cell[][] grid;
		
		pInput = JOptionPane.showInputDialog(null,"Enter passage probability","Maze Input", JOptionPane.OK_CANCEL_OPTION);
		rowInput = JOptionPane.showInputDialog(null,"Enter number of rows","Maze Input", JOptionPane.OK_CANCEL_OPTION);
		colInput = JOptionPane.showInputDialog(null,"Enter number of columns","Maze Input", JOptionPane.OK_CANCEL_OPTION);
		
		p = Double.parseDouble(pInput);
		cols = Integer.parseInt(colInput);
		rows = Integer.parseInt(rowInput);
		
		grid = new Cell[rows][cols];
		
		
		//Assigned a new Cell object with the corresponding array indices
		for(int i = 0; i < rows; i++) {
			for(int j = 0; j < cols; j++) {
				grid[i][j] = new Cell(i,j);
			}
		}
		
		
		//Assigned of neighbor[]
		for(int i = 0; i < rows; i++) {
			for(int j = 0; j < cols; j++) {
				
				//West & East Neighbors
				if (Math.random( )< p && j != (cols - 1)) {
					grid[i][j].setNeighborCell(grid[i][j+1], 1);
					grid[i][j+1].setNeighborCell(grid[i][j], 3);
				}//END EW
				
				//North & South Neighbors
				if (Math.random( )< p && i != rows -1) {
					grid[i][j].setNeighborCell(grid[i+1][j], 2);
					grid[i+1][j].setNeighborCell(grid[i][j], 0);
				}//END NS
				
			//Corners Bottom right being EXIT (modified Maze: Entrance field to change starting point)
				if (i == 0 && j == 0) {
					grid[i][j].setNeighborCell(grid[i][j+1], 1);//east
					grid[i][j+1].setNeighborCell(grid[i][j], 3);
					grid[i][j].setNeighborCell(grid[i+1][j], 2);//south
					grid[i+1][j].setNeighborCell(grid[i][j], 0);
				}//Top-Left
				
				if (i == 0 && j == cols - 1) {
					grid[i][j].setNeighborCell(grid[i][j-1], 3);//west
					grid[i][j-1].setNeighborCell(grid[i][j], 1);
					grid[i][j].setNeighborCell(grid[i+1][j], 2);//south
					grid[i+1][j].setNeighborCell(grid[i][j], 0);
				}//Top-Right
				
				if (i == rows - 1 && j == 0) {
					grid[i][j].setNeighborCell(grid[i][j+1], 1);//east
					grid[i][j+1].setNeighborCell(grid[i][j], 3);
					grid[i][j].setNeighborCell(grid[i-1][j], 0);//north
					grid[i-1][j].setNeighborCell(grid[i][j], 2);
				}//Bottom-Left
			}
		}//END Neighbor NESTED FOR-LOOP
		
		return grid;
		
	}//END loadMazeRandom()
	
	
	/**
	 * This Method implement generated a 2D array of Cells that represents a randomly built maze given 
	 * Precondition: file1 & file2 must be found.
	 * Post-Condition: Returns 2D array of Cell[][] representing the maze;
	 */
	public static Cell[][] loadMazeFromFiles(String file1, String file2){
		
		Cell[][] grid = null;
		int rows;
		int cols;
		
		try {
			File EW = new File(file1);
			File NS = new File(file2);
			Scanner scannerEW = new Scanner(EW);
			Scanner scannerNS = new Scanner(NS);
			
			//Read the first 2 numbers to get dimensions
			rows = scannerEW.nextInt();
			cols = scannerEW.nextInt();
			
			//Making the grid
			grid = new Cell[rows][cols];
			
			//Assigned a new Cell object with the corresponding array indices
			for(int i = 0; i < rows; i++) {
				for(int j = 0; j < cols; j++) {
					grid[i][j] = new Cell(i,j);
				}
			}
			
			//Populate Neighbors = loading numbers found file
			for(int i = 0; i < rows; i++) {
				for(int j = 0; j < cols; j++) {
					
					int ew = scannerEW.nextInt();
					int ns = scannerNS.nextInt();
					
					//West & East Neighbors
					if (ew == 0 && j != (cols - 1)) {
						grid[i][j].setNeighborCell(grid[i][j+1], 1);
						grid[i][j+1].setNeighborCell(grid[i][j], 3);
					}//END EW
					
					//North & South Neighbors
					if (ns == 0 && i != rows -1) {
						grid[i][j].setNeighborCell(grid[i+1][j], 2);
						grid[i+1][j].setNeighborCell(grid[i][j], 0);
					}//END NS
					
				}
			}//END NEIGHBOR NESTED LOOP
			
			return grid;
			
		} catch (IOException e) {
			System.out.println("File not found");
			MazeBuilder.loadMazeRandom();
		}
		
		return grid;
	}
	
	
	
	
	
	
	
}
