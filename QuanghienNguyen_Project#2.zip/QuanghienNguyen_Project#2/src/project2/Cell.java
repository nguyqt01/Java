package project2;

/**
 * 
 * 	Quanghien Nguyen
 * 	CS 260: Project 2
 * 	Professor Petruska
 * 	Date: 3/17/19
 *
 */

public class Cell {
	
	private int row;
	private int column;
	private boolean visited = false;
	private Cell [] neighbor = new Cell[4];
	private int lastOut = -1;
	
	
	/**
	 * 	Constructor initializes the fields row and column
	 * @param row -  store the row index of the cell when it is added to the maze array
	 * @param column -  store the column index of the cell when it is added to the maze array
	 */
	public Cell(int row, int col) {
		this.row = row;
		this.column = col;
	}
	
	
	/**
	 * This method creates a string representation of the coordinates of the cell in the maze
	 * @return - Returns a String containing the coordinates row and column
	 */
	public String toString() {
		String coord = "(" + row + "," + column + ")";
		return coord;
	}



//-------------------------------------------------------------------------- GETTERS & SETTERS ---------------------------------------------------------------------------
	/**
	* Accessor method to get a reference to the neighbor Array
	* @return - a reference to the neighbor Array.
	*/
	public Cell[] getNeighbor() {
		return neighbor;
	}
	
	
	/**
	* Accessor method to get a reference to the neighboring cell
	* @param index - The north, east, south and west neighbors are stored at index 0, 1, 2, 3 in order in the Array
	* Precondition: index must be 0, 1, 2, or 3 < Array Size
	* @return - a reference to the neighboring cell.
	*/
	public Cell getNeighborCell(int index) {
		return neighbor[index];
	}

	
	/**
	* Modification method to set the reference of the neighboring cell
	* @param index - The north, east, south and west neighbors are stored at index 0, 1, 2, 3 in order in the Array
	* @param neighbor - The cell the is being set as the neighboring cell
	* Precondition: index must be 0, 1, 2, or 3 < Array Size
	* Postcondition: The neighboring cell at neighbor[index] is set
	*/
	public void setNeighborCell(Cell neighbor, int index) {
		this.neighbor[index] = neighbor;
	}

	
	/**
	* Accessor method to get lastOut of this cell
	* @return - the int store in this cell lastout field
	*/
	public int getLastOut() {
		return lastOut;
	}

	
	/**
	* Modification method to set the lastOut field in this cell.
	* @param lastOut � What the lastOut field of the cell is being set to.
	* Postcondition: The lastOut of this node has been set to new lastOut.
	*/
	public void setLastOut(int lastOut) {
		this.lastOut = lastOut;
	}

	
	/**
	* Accessor method to see if the cell has been visited
	* @return - True is it has, false if it hasn't
	*/
	public boolean isVisited() {
		return visited;
	}

	
	/**
	* Modification method to set the visited boolean in this cell.
	* @param lastOut � What the visited boolean of the cell is being set to.
	* Postcondition: The visited boolean of this node has been set to argument visited.
	*/
	public void setVisited(boolean visited) {
		this.visited = visited;
	}
	
}
