package project2;

public class Applications {
	
	public static void main(String[] args) {
		
	/***********************UNCOMMENT AND RUN*************************************************************
	
		//Testing a 10 x 10 maze application (traversal path exists)
		Maze yesPathFromFile = new Maze(MazeBuilder.loadMazeFromFiles("eastWest.txt", "northSouth.txt"));
		yesPathFromFile.findPath();
		System.out.println("");
		
		//A 10 x 10 maze application (no traverse exists)
		Maze noPathFromFile = new Maze(MazeBuilder.loadMazeFromFiles("eastWest.txt", "northSouth1.txt"));
		noPathFromFile.findPath();
		
	******************************************************************************************************/
		
		//Manually ran for all test of Random Mazes (Didn't use loop for testing)
		Maze randomMazeTest = new Maze(MazeBuilder.loadMazeRandom());
		randomMazeTest.findPath();
		
	}
	
}
