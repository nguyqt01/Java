package project2;

/**
 * 
 * 	Quanghien Nguyen
 * 	CS 260: Project 2
 * 	Professor Petruska
 * 	Date: 3/17/19
 *
 */

public class Stack<T> {
	
	private Node<T> top;
	
	/**
	 * 	Empty Constructor
	 */
	public Stack() {
	}
	
	
	/**
	 * This method adds a  Node on top of the stack
	 * Precondition: Stack cannot be empty
	 * Postcondition: The new Top is the Node added
	 * @return - Returns the data of the Node that was removed
	 */
	public void push(T item) {
	      top = new Node<T>(item, top);
	}

	
	/**
	 * This method remove the top Node from the stack
	 * Precondition: Stack cannot be empty
	 * Postcondition: The new Top is the Node linked to the Node being removed
	 * @return - Returns the data of the Node that was removed
	 * @Underflow - Print Stack is empty
	 */
	public Node<T> pop() {
		
		Node<T> popNode;
		
	    if (isEmpty()) {
	    	System.out.println("The Stack is empty. No item to Pop.");
	        return null;
	    }
	    
	    popNode = top;
	    top = top.link;
	    return popNode;
	}

	
	/**
	 * This method takes a peek of the data of the top Node of the Stack
	 * Precondition: Stack cannot be empty
	 * @return - Returns the data of top Node
	 * @Underflow - Print Stack is empty
	 */
	public T peek() {
		
		if (isEmpty()) {
			System.out.println("The Stack is empty. No item to peek.");
            return null;
		}
		return top.data;
	}
	
	
	/**
	 * This method checks if the Stack is empty
	 * @return - Returns true if Stack is empty else return false
	 */
	public boolean isEmpty() {
		return (top == null);
	}
	
	
	/**
	 * This method calculates the length of the Stack by iterating thru the list starting from the top of the stack it counts the nodes and returns the count
	 * Postcondition: The number of Nodes are counted starting from the top Node in the Stack to the bottom Node of the stack which has a null link.
	 * @return - The return value is the number of nodes in the LinkedList used to store the Stack.
	 * */
	public int size() {
		
		if (isEmpty()) {
			return 0;
		}
		
		Node<T> cursor = top.link;
		int numNodes = 1;
		
		while(cursor != null){
			cursor = cursor.link;
			numNodes++;
		}
		
		return numNodes;
	}
	
	
	/**
	 * This method iterates thru the list from the calling node and prints data values to the console.
	 * Precondition: A Stack<T> can only call this methods
	 * Postcondition: Prints data values of the list of nodes to the console, the size of of the list
	 */
	public void display() {
		
		if (isEmpty()) {
			return;
		}
		
		Node<T> popNode = pop();
		display();
		System.out.println(popNode.data.toString());
	}
	
	
//---------------------------------------INNER NODE CLASS --------------------------------------------------------------
	class Node<T> {
		
		private T data;
		private Node<T> link;
		
		
		/**
		 * 	Constructor initializes data and link to next node.
		 * 	The link may be null to indicate that there is nothing
		 * 	after it.
		 *  @param data - This is the initial data of the new node.
		 *  @param link - This is a reference to the node after this node can be null.
		 */
		public Node(T data, Node<T> link) {
			this.data = data;
			this.link = link;
		}
		
	}//End of NODE CLASS
	
	
}//End of STACK CLASS



