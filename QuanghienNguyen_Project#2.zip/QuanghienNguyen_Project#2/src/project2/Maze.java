package project2;
import javax.swing.*;

/**
 * 
 * 	Quanghien Nguyen
 * 	CS 260: Project 2
 * 	Professor Petruska
 * 	Date: 3/17/19
 *
 */

public class Maze {
	
	private Cell entrance;
	private Cell exit;
	private Cell[][] grid;
	private int rows;
	private int columns;
	private boolean pathFound;
	private Stack<Cell> path;
	
	
	/**
	 * Constructor initializes initializes the grid array, assigns grid dimensions, assigns entrance and exit
	 * @param grid - A 2-dimensional array of cells to use to initialize the maze
	 * Precondition: grid cannot be null;
	 * Post-Condition: 	Columns & rows fields are set according to the dimension of grid, index is set to the cell in grid[0][0] (top-right), and exit is set to grid[columns - 1][rows - 1] (bottom-left)
	 * 					Initializes the grid array.
	 */
	public Maze(Cell[][] grid) {
		this.grid = grid;
		this.rows = grid.length;
		this.columns = grid[0].length;
		this.entrance = grid[0][0];
		this.exit = grid[this.rows - 1][this.columns - 1];
		this.path = new Stack<Cell>();
		
	}
	
	
	/**
	 * This Method implement the search if their is a path through the maze from the entrance to the exit
	 * Precondition: Entrance cannot be null
	 * Post-Condition: Depending on pathFound creates output messages; displays the output using JOptionPane message dialogs and print the path onto the console if founded.
	 */
	public void findPath() {
		
		path.push(entrance);
		entrance.setVisited(true);
		
		while (path.isEmpty() == false && pathFound == false) {
			
			if(path.peek() == exit) {
				JOptionPane.showMessageDialog(null, "The maze has a traversing path.\nCell coordinates are listed on the console", "Result of the Search", JOptionPane.WARNING_MESSAGE);
				System.out.println("The lenght of the path is " + path.size() + "\nCells on the traversin path:\n");
				path.display();
				System.out.println("Random maze has been searched");
				
				pathFound = true;
				return;
			}//END of IF
			
			for(int i = 0; i < 4 ; i++) {
				
				if( path.peek().getNeighborCell(i) != null && path.peek().getNeighborCell(i).isVisited() == false) {
					path.peek().getNeighborCell(i).setVisited(true);
					path.push(path.peek().getNeighborCell(i));
					break;
				} else if (i == 3){
					path.pop();
				}
			}//END FOR LOOP
	
		}//END WHILE LOOP
		
		JOptionPane.showMessageDialog(null, "No traversing path was found.", "Result of the Search", JOptionPane.WARNING_MESSAGE);
	}//END findPath
	
	
	
}//END MAZE CLASS
